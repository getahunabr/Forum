import React, { useEffect, useState, createContext } from "react";
import { useNavigate, Route, Routes } from "react-router-dom";
import LoginPage from "./pages/LoginPage/LoginPage";
import HowitWork from "./pages/HowItWork/HowitWork";
import QuestionAnswer from "./pages/QuestionAnswer/QuestionAnswer";
import axios from "./axiosConfig";
import Home from "./Components/Home/Home";
import AnswerPage from "./pages/AnswerPage/AnswerPage";

export const AppState = createContext();
function App() {
  const [user, setUser] = useState({});
  const token = localStorage.getItem("token");
  console.log(token)
  const navigate = useNavigate();
  async function checkUser() {
    try {
      const { data } = await axios.get("/users/check", {
        headers: { Authorization: "Bearer" + token },
      });
      setUser(data);
    } catch (error) {
      console.log(error.response);
      navigate("/");
    }
  }
  useEffect(() => {
    checkUser();
  }, []);
  return (
    <AppState.Provider value={{ user, setUser }}>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/howItWork" element={<HowitWork />} />
        <Route path="/question" element={<QuestionAnswer />} />
        <Route path="/home" element={<Home/>} />
        <Route path="/answer" element={<AnswerPage/>} />
        
      </Routes>
    </AppState.Provider>
  );
}

export default App;

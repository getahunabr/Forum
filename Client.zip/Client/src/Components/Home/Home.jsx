import React from "react";
import logo from "../../assets/evangadi-logo-home.png";
import "./home.css";
import { Link } from "react-router-dom";
import img1 from "../../assets/10002.svg";
import img2 from "../../assets/10003.svg";
import img3 from "../../assets/10001.png";
import { IoSearchOutline } from "react-icons/io5";

const Home = () => {
  return (
    <section>
      <header className="nav__bar ">
        <nav className="navigation">
          <div className="container">
            <div className="outer__continer">
              <div className="evLogo__continer">
                <img src={logo} alt="evangadi-logo" />
              </div>
              <div className="nav__links">
                <ul className="lists__cont">
                  <li className="howItWork hovechange"></li>
                  <li>
                    <button className="butn signin__butn">
                      <Link to="/question">Ask Question ?</Link>
                    </button>
                  </li>

                  <li className="home hovechange">
                    <Link to="/">Log-out</Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </nav>
      </header>
      <div className="bg">
        <div className="img_display">
          <div className="first_img_cont">
            <img src={img1} alt="" />
          </div>
          <div className="therd_img_cont">
            <input className="search" type="text" placeholder="Search" />
            <span className="search_icon">
              <IoSearchOutline size={35} />
            </span>
            <img src={img3} alt="" />
          </div>
          <div className="second_img_cont">
            <img src={img2} alt="" />
          </div>
        </div>
      </div>
      <div className="middle_section">
      <div className="tag_column">
        <ul>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        </ul>
      </div>
      <div className="question_column"></div>
      </div>
      

      <button className="butn signin__butn">
        <Link to="/answer">Answer</Link>
      </button>
    </section>
  );
};

export default Home;

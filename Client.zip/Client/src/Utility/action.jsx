export const Type = {
  SET_USER: "SET_USER",
};

import { useContext, useState, useEffect } from "react";
import { AppState } from "../../App";
import "./questionAnswer.css";
import Layout from "../Layout/Layout";
import axios from "../../axiosConfig";
import { Link } from "react-router-dom";
import { BsCheck2Square } from "react-icons/bs";
import img from '../../assets/stick_figure_sit_in_question_mark_300_nwm (1).jpg'
const QuestionAnswer = () => {
  const user = useContext(AppState);
  let [titleValue, setTitleValue] = useState("");
  let [discriptionValue, setDiscriptionValue] = useState("");
  let [questionResponse, setQuestionResponse] = useState("");

  console.log(user);
  useEffect(() => {
    // Function to clear the message after 3 seconds (3000 milliseconds)
    const clearMessage = setTimeout(() => {
      setQuestionResponse("");
      // window.location.reload();
    }, 2000);

    // Clean up the timeout to prevent memory leaks
    return () => clearTimeout(clearMessage);
  }, [questionResponse]);

  function submit(e) {
    e.preventDefault();
    setQuestionResponse("");
    if (!titleValue || !discriptionValue) {
      return setQuestionResponse(
        "Question title or Discrtiption can not be empty"
      );
    }
    const token = localStorage.getItem("token");
    try {
      const payload = {
        title: titleValue,
        description: discriptionValue,
      };
      axios.post("/questions/ask-questions", payload, {
        headers: {
          authorization: "Bearer " + token,
        },
      });
      alert("question asked");
    } catch (error) {}
  }

  return (
    <Layout>
      <section className="explained">
        <div className="evan_net_exp">
          <div className="title">
            <h1>Question Page</h1>
            <small>A place to grow together</small>
          </div>
        </div>
        <div className="question_steps">
        <div className="img_contener">
            <img src={img} alt="" />
          </div>
          <div className="step_listes">
          <h1>Steps To Write a Good Question</h1>
          <ul>
            <li>
              <span>
                <BsCheck2Square size={23} color="#2ca87d" />
              </span>
              Describe your problem in more detail.
            </li>
            <li>
              <span>
                <BsCheck2Square size={23} color="#2ca87d" />
              </span>{" "}
              Summarize your problem in a one-line title.
            </li>
            <li>
              <span>
                <BsCheck2Square size={23} color="#2ca87d" />
              </span>
              Describe what you tried and what you expected to happen.
            </li>
            <li>
              <span>
                <BsCheck2Square size={23} color="#2ca87d" />
              </span>
              Review your question and post it to the site.
            </li>
          </ul>
          </div>
          
          <hr />
        </div>
        <div className="ask_container">
          <h1 className="text-gradient">Ask a Public Question</h1>
            <select className="tag" name="" id="">
              <option value="">Select Tag</option>
            </select>
            <form action="">
            <div className="title_contener">
              
              <input className="title_input" type="text" placeholder="Title" />
            </div>
            <div className="question">
              
              <textarea
                id="bio"
                name="bio"
                rows="3"
                cols="30"
                placeholder="Question Content"
              ></textarea>
            </div>
            <button className="butn">Post your Question</button>
            </form>
           
          </div>
      </section>
    </Layout>
  );
};

export default QuestionAnswer;

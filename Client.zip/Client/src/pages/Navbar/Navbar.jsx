import React from "react";
import logo from "../../assets/evangadi-logo-home.png";
import "./navbar.css";
import { Link } from "react-router-dom";
Link;

const Navbar = () => {
  return (
    <header className="nav__bar ">
      <nav className="navigation">
        <div className="container">
          <div className="outer__continer">
            <div className="evLogo__continer">
              <img src={logo} alt="evangadi-logo" />
            </div>
            <div className="nav__links">
              <ul className="lists__cont">
               
                <li>
                  <button className="butn signin__butn">
                    <Link to="/" onClick={() => reload()}>
                      SIGN IN
                    </Link>
                  </button>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;

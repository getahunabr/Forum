import React from 'react'
import './answerPage.css'
import Layout from '../Layout/Layout'
import imgA from '../../assets/6d1dc4b1793d6c5c2ef40402171bff07.gif'
import { BsCheck2Square } from "react-icons/bs";
const AnswerPage = () => {
  return (
    <Layout>
    <section className="explained">
      <div className="evan_net_exp">
        <div className="title">
          <h1>Answer Page</h1>
          <small>A place to grow together</small>
        </div>
      </div>
      <div className="steps">
      <div className="img_contener">
          <img src={imgA} alt="" />
        </div>
        <div className="answer_step_listes">
        <h1>Steps To Write a Good Answer</h1>
        <ul>
          <li>
            <span>
              <BsCheck2Square size={23} color="#2ca87d" />
            </span>
            Read the question carefully
           
          </li>
          <li>
            <span>
              <BsCheck2Square size={23} color="#2ca87d" />
            </span>{" "}
             Understand the question well
          </li>
          <li>
            <span>
              <BsCheck2Square size={23} color="#2ca87d" />
            </span>
            Use simple language
          </li>
          <li>
            <span>
              <BsCheck2Square size={23} color="#2ca87d" />
            </span>
            Write to the best of your ability
          </li>
        </ul>
        </div>
        
        <hr />
      </div>
      <div className="answer_container">
        <h1 className="answer_text-gradient">Give a Public Answer</h1>
         
          <form action="">
          
          <div className="question">
            
            <textarea
              id="bio"
              name="bio"
              rows="3"
              cols="30"
              placeholder="Answer Content"
            ></textarea>
          </div>
          <button className="butn">Submit your Answer</button>
          </form>
         
        </div>
    </section>
  </Layout>
  )
}

export default AnswerPage
